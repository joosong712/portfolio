

// console.log(songDate.탭메뉴[0].itemName);


var tabData = {
    lastModify : "2019-01-07",
    useType : "sub page",
    tabItems : [{
            itemName: "학교",
            itemColor: "red",
            itemContent: "학교에 관한 내용들입니다."
        },
        {
            itemName: "공원",
            itemColor: "black",
            itemContent: "공원에 관한 내용들입니다."
        },
        {
            itemName: "놀이터",
            itemColor: "blue",
            itemContent: "놀이터에 관한 내용들입니다."
        },
        {
            itemName: "집안",
            itemColor: "violet",
            itemContent: "놀이터에 관한 내용들입니다."
        },
        {
            itemName: "사무실",
            itemColor: "green",
            itemContent: "놀이터에 관한 내용들입니다."
        }
    ]
}